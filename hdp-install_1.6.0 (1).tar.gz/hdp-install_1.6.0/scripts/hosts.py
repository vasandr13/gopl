#!/usr/bin/python

# Generate inventroy for hdp-automation playbooks

import yaml
import os

if ('HDPI_CFG' not in os.environ 
        or os.environ['HDPI_CFG'] == "default"):
    con_file = 'config.yml'
else:
    con_file = os.environ['HDPI_CFG']

config = yaml.load(open(con_file))

inventroy = {}
inventroy['all'] = {}
inventroy['all']['children'] = []

# agents-nodes
inventroy['ambari_agent'] = {}
ambari_agent = ['namenode', 'secondary_namenode', 
                'journalnode','zookeeper', 'datanode',
                'clients', 'ambari_metrics', 'kafka',
                'oozie', 'hive_server', 'hive_metastore',
                'hbase_master', 'hbase_region', 'spark',
                'ranger_admin', 'ranger_usersync',
                'knox', 'sqoop', 'ambari_infra', 
                'zeppelin_notebook', 'edgenodes']

inventroy['ambari_agent']['children'] = ambari_agent

# databases
inventroy['databases'] = {}
databases = ['postgresql_master', 'postgresql_slaves']
inventroy['databases']['children'] = databases

# ranger
inventroy['ranger'] = {}
rangers = ['ranger_admin', 'ranger_usersync']
inventroy['ranger']['children'] = rangers

# hdfs
inventroy['hdfs'] = {}
hdfss = ['namenode', 'secondary_namenode', 'journalnode', 'datanode']
inventroy['hdfs']['children'] = hdfss

# yarn
inventroy['yarn'] = {}
yarns = ['nodemanager', 'app_timeline', 'resourcemanager']
inventroy['yarn']['children'] = yarns

# hive
inventroy['hive'] = {}
hives = ['hive_server', 'hive_metastore']
inventroy['hive']['children'] = hives

# hive
inventroy['hbase'] = {}
hbases = ['hbase_master', 'hbase_region']
inventroy['hbase']['children'] = hbases

# groups
for group in config['cluster_hosts']:
    if group not in ["ambari_agent", "databases"]:
        inventroy[group] = {}
        inventroy[group]['hosts'] = []
        inventroy['all']['children'].append(group)

        if config['cluster_hosts'][group] is not None:
            for host in config['cluster_hosts'][group]:
                inventroy[group]['hosts'].append(host)

print (inventroy)
