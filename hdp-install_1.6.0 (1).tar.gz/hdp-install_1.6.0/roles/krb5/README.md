# krb5

Роль ansible для операций с krb5-workstation.

## Разработка 

Maintainer: @dslampsy

Разработка должна вестись в отдельных ветках, с MR в мастер который вешается на maintainer. После merge ветки будут удаляться. 

Для версионирования используется semver - https://semver.org/. 


## Использование

```yaml
- name: "Setup krb5"
  hosts: ...
  vars:
    krb__realms:
      - name: "MSK.MTS.RU"
        admin_server: "0700MSKRWDC05.msk.mts.ru"
        kdc: "0700MSKRWDC04.msk.mts.ru"
    krb__default_realm: "MSK.MTS.RU"
    krb__java_home: "/usr/java/jdk1.8.0_201-amd64"
  roles:
    - { role: krb5, krb5__action: setup }


- name: "Delete krb5"
  hosts: ...
  roles:
    - { role: krb5, krb5__action: delete }
```


## Переменные

- `krb5__action` - тип операции выполняемой в роли. Доступные операции:
  - `setup` - установка и настрйока krb5-workstation.
  - `delete` - удаление krb5-workstation.

- `krb__ticket_lifetime` - Время жизни созданого kerberos ticket. По умолчанию - '24h'.

- `krb__renew_lifetime` - Время обновления kerberos ticket. По умолчанию - '7d'.

- `krb__realms` - Список используемых в клиенте realm. Должен содержать следующие параметры:
  - `name` - имя realm
  - `admin_server` - административный сервер
  - `kdc` - сервер kdc

  Пример:
  ```yaml
  - name: MSK.MTS.RU
    admin_server: "0700MSKRWDC05.msk.mts.ru"
    kdc: "0700MSKRWDC04.msk.mts.ru"
  ```

- `krb__default_realm` - Используемый по умолчанию realm. По умолчанию '' (пустой).

- `krb__install_jce` - Устанавливать политики для java. По умолчанию 'true'.

- `krb__java_home` - Путь к JAVA_HOME. По умолчанию - '/usr/java/jdk1.8.0_201-amd64'.

