# postgresql

Роль для установки, удаления и выполнения операций с PostgreSQL.

Доступные на текущий момент операции:
- Установка
- Удаление
- Операции с БД - создание, удаление, бекап, восстановление
- Операции с ролями (пользователями) БД - создание
- Операции с расширениями для БД - создание
- Операции с разрешениями для БД - создание


<!-- ---------------------------------------------------------------------- -->
# Установка

Доступны режимы утсановки **single** и **master/slave**. <br>
Для настройки режима master/slave требуется указать значение переменных `postgresql__master` и `postgresql__slaves` (описание ниже).

## Использование

Установка PostgreSQL 9.6 (single node):

```yaml
- name: "Install PG"
  hosts: fake_host
  vars:
    postgresql__version: 9.6
    postgresql__data: /data/postgre/9.6/data
    postgresql__pg_hba:
      - { type: local, database: all, user: postgres, auth_method: peer }
      - { type: local, database: all, user: all, auth_method: peer }
      - { type: host, database: all, user: all, address: '127.0.0.1/32', auth_method: md5 }
      - { type: host, database: all, user: all, address: '::1/128', auth_method: md5 }
      - { type: host, database: all, user: all, address: '0.0.0.0/0', auth_method: md5 }
  roles:
   - { role: 'postgresql', postgresql__action: 'install' }
```

Установка PostgreSQL 9.6 (master/slave):

```yaml
- name: "Install PG"
  hosts: fake_hosts
  vars:
    postgresql__master:
      name: 'fake-pg-01'
      ip: '192.168.0.1'
      cidr:'24'
      port: '5432'

    postgresql__slaves:
      - { name: 'fake-pg-02', ip: '192.168.0.2', cidr:'24', port: '5432' }
      - { name: 'fake-pg-03', ip: '192.168.0.3', cidr:'24', port: '5432' }

    postgresql__version: 9.6

    postgresql__data: /data/postgre/9.6/data

    postgresql__pg_hba:
      - { type: local, database: all, user: postgres, auth_method: peer }
      - { type: local, database: all, user: all, auth_method: peer }
      - { type: host, database: all, user: all, address: '127.0.0.1/32', auth_method: md5 }
      - { type: host, database: all, user: all, address: '::1/128', auth_method: md5 }
      - { type: host, database: all, user: all, address: '0.0.0.0/0', auth_method: md5 }

  roles:
   - { role: 'postgresql', postgresql__action: 'install' }
```

## Переменные

- `postgresql__version` : Версия PosgreSQL. <br>
  По умолчанию - **9.6**.

- `postgresql__version_minor` : (Опционально) Минорная версия пакета из репозитория. Используется при необходимости установить конкретный минорный релиз.

- `postgresql__repo_url` : Ссылка на репозиторий с дистрибутивами PosgreSQL. <br>
    Значение по умолчанию:
    ```
    {{ __artifactory_repository }}/postgresql/repos/yum/{{ postgresql__version }}/redhat/rhel-$releasever-x86_64/
    ```

- `postgresql__repofile_url` : (Опционально) Ссылка непосредственно на файл .repo для доставки на хосты. Если эта переменная задана, то `postgresql__repo_url` игнорируется.

  > Предусмотрено 2 способа доставки файла репозитория на хост: cкачивание файла .repo с хоста. (переменная `postgresql__repofile_url`) или формирование файла .repo по шаблону с указанием репозитория postgresql. (переменная `postgresql__repo_url`).

- `postgresql__data` : Путь к директории с данными PosgreSQL. <br>
  По умолчанию:
  ```
  /var/lib/pgsql/{{ postgresql__version }}/data
  ```

- `postgresql__master` : Переменная определяющая master хост PostgreSQL. В данной перемеенной должен быть указан **только 1 хост**. Если данная группа не указана, будет произведена single установка. Переменная должна содержать след. параметры (пример):
  ```yaml
  postgresql__master:
    name: 'fake-pg-01'
    ip: '192.168.0.1'
    cidr:'24'
    port: '5432'
  ```

- `postgresql__slaves` : Переменная определяющая список хостов slave. Если данная группа не указана, будет произведена single установка.  Переменная должна содержать след. параметры (пример):
  ```yaml
  postgresql__slaves:
    - { name: 'fake-pg-02', ip: '192.168.0.2', cidr:'24', port: '5432' }
    - { name: 'fake-pg-03', ip: '192.168.0.3', cidr:'24', port: '5432' }
  ```

- `postgresql__repl_user` : имя роли (пользователя) для настройки репликации master - slave. <br>
  По умолчанию - **repl**

- `postgresql__repl_user_pass` : пароль для учётной записи пользователя для репликации master/slave. <br>
  По умолчанию - **repl**

- `postgresql__pg_hba` : Список переменных для настройки файла pg_hba.conf. Смотри подробнее [здесь](https://www.postgresql.org/docs/current/static/auth-pg-hba-conf.html). <br>
  По умолчанию:
  ```yaml
  postgresql__pg_hba:
    - { type: local, database: all, user: postgres, auth_method: peer }
    - { type: local, database: all, user: all, auth_method: peer }
    - { type: host, database: all, user: all, address: '127.0.0.1/32', auth_method: md5 }
    - { type: host, database: all, user: all, address: '0.0.0.0/0', auth_method: 'ldap ldapserver=ldap-slave4.msk.mts.ru ldapsearchattribute=uid ldapbasedn="dc=mts,dc=ru" ldapbinddn="{{ __ldap_bind_dn }}" ldapbindpasswd="{{ __ldap_bind_password }}"' }
    - { type: host, database: all, user: all, address: '::1/128', auth_method: md5 }
  ```

- `postgresql__pg_conf` : Список переменных для настройки файла postgresql.auto.conf. Присутствуют значения по умолчанию. <br>
  **Внимание!** Указанное в playbook значение данной переменной затирает значения по умолчанию. <br>

  По умолчанию для sigle установки:
  ```yaml
  postgresql__pg_conf:
    port: 5432
    listen_addresses: "'*'"
    max_connections: 100
  ```

  По умолчанию для master/slave:
  ```yaml
  postgresql__pg_conf:
    port: 5432
    listen_addresses: "'*'"
    synchronous_commit: "local"
    max_wal_senders: 3
    wal_keep_segments: 15
    synchronous_standby_names: "'*'"
    wal_level: "hot_standby"
    archive_mode: "on"
    wal_log_hints: "on"
    hot_standby: "on"
    max_wal_size: "1GB"
    min_wal_size: "80MB"
  ```
- `postgresql__use_lvm` : признак использовая LVM для pgdata. <br>
  По умолчанию -
- `postgresql__vg` : Название группы LVM для создания <br>
  По умолчанию - **PGVG**
- `postgresql__lv` : Параметры logical volume.
  - `name` : Название <br>
    По умолчанию - **pgdata**
  - `size` : Размер <br>
    По умолчанию - **"100%FREE"**
  - `fstype` : тип файловой системы на lvm. <br>
    По умолчанию - **ext4**
  - `mount` : Точка монтирования lvm. <br>
    По умолчанию - **{{ postgresql__data }}**

<!-- ---------------------------------------------------------------------- -->
# Удаление

Удаляет пакеты, и все данные PostgreSQL.

## Использование

```yaml
- name: "Delete PG"
  hosts: fake_hosts
  vars:
    postgresql__version: 9.6
    postgresql__data: /data/postgre/9.6/data
  roles:
    - { role: 'postgresql', postgresql__action: 'delete' }

```


<!-- ---------------------------------------------------------------------- -->
# Создание БД

Доступно создание обычной БД и БД ограниченной по размеру (через lvm разделы).

## Регулярные БД

**ВАЖНО!** При режиме master/slave выполнять роль необходимо на master.

**ВАЖНО!** Не рекомендуется использовать этот параметр для обновления параметров уже существующих БД, так как в будущем это может привести к неопределенным последствиям. Как например, на текущий момент возможна смена владельца БД, но при этом не меняются владельцы уже существующих таблиц. При этом, на github.com весит запрос о добавлении возможности смены владельцев таблиц. Запрос: https://github.com/ansible/ansible/issues/29774


### Использование

Создание двух БД и назначение владельцем роль fake_user:

```yaml
- name: "Create db"
  hosts: fake_master_hosts
  vars:
    postgresql__db:
      - name: fake_db_1
        owner: fake_user

      - name: fake_db_2
        owner: fake_user

  roles:
    - { role: 'postgresql', postgresql__action: 'db/create' }
```

## Лимитированные БД

Ограничение размера БД производится через создаваемые lvm разделы.
Данный тип создания происходит при указании опции `lvm` в переменной `postgresql_db`.

**ВАЖНО!** При использовании master/slave, необходимо запускать роль на всех серверах кластера. Операция создания БД производится только на мастере, который определяется через переменную `postgresql__master`.

### Использование

Создание лимитированной БД:

```yaml
- name: "Create limited db"
  hosts: fake_pg_hosts
  vars:
    postgresql__master:
      name: 'fake-pg-01'

    postgresql__db_user: postgres

    postgresql__db:
      - name: fake_lim_db_1
        owner: fake_user
        lvm:
          volume_group: 'PGVG'
          size_limit: '200G'
        db_owner: fake_pm_user
        expire_date: '31-12-2018'
        project: fake_project
        description: 'Ticket DEVOPS-1'

  roles:
    - { role: 'postgresql', postgresql__action: 'db/create' }
```



## Переменные

- `postgresql__db_user` : Пользователь, под которым будут производиться операции в PostgreSQL. <br>
  По умолчанию - **postgres**

- `postgresql__db` : Содержит список баз данных, с которыми необходимо произвести операцию. Переменная должна содержать параметры, полностью соответствующие параметрам модуля ansible - **postgresql_db** + доступны опциональные параметры:
  - `description` - комментарий описание к БД.
  - `db_owner` - "хозяин" базы данных. К кому приходить с вопросами.
  - `size_limit` - Лимит размера БД (если используется)
  - `expire_date` - дата окончания срока действия БД.
  - `project` - название проекта в рамках которого создана БД.
  - `lvm` - переменная настроек lvm (определяет тип создаваемой БД). Содержит 2 обязательные опции:
    - `volume_group` - имя группы LVM.
    - `size_limit` - Лимит для БД. Например 200G.

В создание БД добавлена возможность добавлять комментарии к базе данных. Для добавления комментария к БД должна быть определена опция `description` переменной `postgresql__db`.

Пример:
```yaml
postgresql__db:
  - name: fake_db_1
    owner: fake_user
    db_owner: fake_pm_user
    project: fake_project
    expire_date: 1.1.2020
    description: DEVOPS-1
```
Описание будет:
```
'fake_pm_user ||  || 1.1.2020 || fake_project || DEVOPS-1'
```


<!-- ---------------------------------------------------------------------- -->
# Удаление БД


### Использование

Удаление регулярной БД

```yaml
- name: "Delete db"
  hosts: fake_master_hosts
  vars:
    postgresql__db_user: postgres

    postgresql__db:
      - name: fake_lim_db_1

  roles:
    - { role: 'postgresql', postgresql__action: 'db/delete' }
```
Удаление лимитированой БД

```yaml
- name: "Delete db"
  hosts: fake_hosts
  vars:
    postgresql__db_user: postgres

    postgresql__db:
      - name: fake_lim_db
        lvm:
          volume_group: 'VGname'

  roles:
   - {role: 'postgresql', postgresql__action: 'db/delete'}
```

<!-- ---------------------------------------------------------------------- -->
# Создание пользователя(роли) БД

**ВАЖНО!** При режиме master/slave выполнять роль необходимо на master.

## Использование

```yaml
- name: "Create user"
  hosts: fake_master_hosts
  vars:
    postgresql__users:
      - name: fake_user
        password: fakepassword
  roles:
    - { role: 'postgresql', postgresql__action: 'user/create' }
```

## Переменные

- `postgresql__db_user` : Пользователь, под которым будут производиться операции в PostgreSQL. <br>
  По умолчанию - **postgres**

- `postgresql__users` : Содержит список пользователей (ролей), которые необходимо добавить или обновить. Переменная должна содержать параметры, полностью соответствующие параметрам модуля ansible - **postgresql_user**.



<!-- ---------------------------------------------------------------------- -->
# Создание расширения для БД

**ВАЖНО!** При режиме master/slave выполнять роль необходимо на master.

## Использование

```yaml
- name: "Create extention"
  hosts: fake_master_hosts
  vars:
    postgresql__extentions:
      - database: fake_db
        extension:  fake_ext
  roles:
    - { role: 'postgresql', postgresql__action: 'extention/create' }
```

## Переменные

- `postgresql__db_user` : Пользователь, под которым будут производиться операции в PostgreSQL. <br>
  По умолчанию - **postgres**

- `postgresql__extentions` :  Содержит список расширений для баз данных, с которыми необходимо произвести операцию. Переменная должна содержать параметры, полностью соответствующие параметрам модуля ansible - **postgresql_ext**.


<!-- ---------------------------------------------------------------------- -->
# Выдача разрешения для БД

**ВАЖНО!** При режиме master/slave выполнять роль необходимо на master.

## Использование

```yaml
- name: "Create extention"
  hosts: fake_master_hosts
  vars:
    postgresql__privileges:
      database: "database_name_1"
      roles: "sa0000tech_user_name"
      privs: "SELECT,INSERT,UPDATE,DELETE"
      type: "table"
      schema: "public"
      objs: "ALL_IN_SCHEMA"
  roles:
    - { role: 'postgresql', postgresql__action: 'user/grant' }
```

## Переменные

- `postgresql__db_user` : Пользователь, под которым будут производиться операции в PostgreSQL. <br>
  По умолчанию - **postgres**

- `postgresql__privileges` :  Содержит список разрешений, которые необходимо добавить. Переменная должна содержать параметры, полностью соответствующие параметрам модуля ansible - **postgresql_privs**.


<!-- ---------------------------------------------------------------------- -->

# Авторы

- Строкин Кирилл Владимирович strokin@mts.ru
- Гафуров Ильдар Ильдусович iigafur1@mts.ru
- Платонов Александр Александрович aaplato8@mts.ru
- Лампси Дмитрий Сергеевич - <dslampsy@mts.ru>
