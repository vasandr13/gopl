import sys
import os
from resource_management import *

class Slave(Script):
  def install(self, env):
    print 'Install'

  def configure(self, env):
    print 'Configure';

  def stop(self, env):
    print 'Stop';
    Execute ( "rm -rf /tmp/dummy_edgenode.pid" )

  def start(self, env):
    print 'Start';
    Execute ( "touch /tmp/dummy_edgenode.pid" )

  def status(self, env):
    print 'Status';
    if not os.path.isfile('/tmp/dummy_edgenode.pid'):
      raise ComponentIsNotRunning()


if __name__ == "__main__":
  Slave().execute()