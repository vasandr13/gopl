# ambari-server

Роль ansible для операций с Ambari Server.

## Разработка 

Maintainer: @dslampsy

Разработка должна вестись в отдельных ветках, с MR в мастер который вешается на maintainer. После merge ветки будут удаляться. 

Для версионирования используется semver - https://semver.org/. 


## Использование


```yaml
- name: Prechecks hosts for Ambari Server install
  hosts: ...
  roles:
    - { role: ambari-server, ambari_server__action: prechecks }


- name: Prepare hosts for Ambari Server install
  hosts: ...
  roles:
    - { role: ambari-server, ambari_server__action: prepare }


- name: Install Ambari Server
  hosts: ...
  vars:
    ambari_server__version: "2.7.3.0"
    ambari_server__java_home: "/usr/java/jdk1.8.0_152"
    ambari_server__db_host: "fake.foo.bar"
    ambari_server__db_host_port: 5432
    ambari_server__db_name: ambari
    ambari_server__db_user: ambari
    ambari_server__db_user_pass: fake
  roles:
    - { role: ambari-server, ambari_server__action: setup }


- name: Delete Ambari Server
  hosts: ...
  roles:
    - { role: ambari-server, ambari_server__action: delete }


- name: Install custom MISC service
  hosts: ...
  roles:
    - { role: ambari-server, ambari_server__action: misc_service }


- name: Configure AD integration in Ambari
  hosts: ...
  vars:
    ambari_server__ldap_url: "fake1.msk.mts.ru:636"
    ambari_server__ldap_secondary_url: "fake2.msk.mts.ru:636"
    ambari_server__ldap_manager_dn: "CN=fake,OU=MTSUsers,DC=msk,DC=mts,DC=ru"
    ambari_server__ldap_manager_password: ...
  roles:
    - { role: ambari-server, ambari_server__action: ldap }


- name: Configure group sync for Ambari
  hosts: ...
  vars:
    ambari_server__groups_ldap: ["group1", "group2"]
  roles:
    - { role: ambari-server, ambari_server__action: groups_ldap }

```


## Переменные

- `ambari_server__action` - тип операции выполняемой в роли. Доступные операции:
  - `setup` - установка и настрйока Ambari Server. НЕ включает в себя шаги `prechecks`, `prepare`, `repo`, их необходимо запустить до установки.
  - `prechecks` - проверки конфигурации хоста перед установкой Ambari Server.
  - `repo` - настройка репозиториев для Ambari Server.
  - `prepare` - подготовка хоста для установки Ambari Server. Включает в себя шаг `repo`.
  - `datasource` - конфигурирование datasource Ambari Server.
  - `delete` - удаление Ambari Server и его артефактов.
  - `misc_service` - добавление в Ambari custom сервиса `MISC`, позволяющего установить "фейковые" сервисы для Ambari UI, PostgreSQL и Edgenodes. **Внимание!** - после добавления сервиса Ambari Server будет перезагружен.
  - `ldap` - выполняет настройку ldap/ad интеграции для Ambari.
  - `groups_ldap` - синхронизирует группы (и пользователей в них) ldap/ad с Ambari

- `ambari_server__version` - версия Ambari Server для установки. По умолчанию: '2.7.3.0'

- `ambari_server__repofile` - ссылка на файл репозитория для скачивания на хост. По умолчанию: 'http://rep.msk.mts.ru/artifactory/files/repofiles/Ambari-{{ ambari_server__version }}.repo'

- `ambari_server__java_home` - Путь к JDK, который будет использован в Ambari Server.

- `ambari_server__db_host` - Хост с PostgreSQL, который будет использован как datasource к Ambari Server.

- `ambari_server__db_host_port` - Порт `ambari_server__db_host` для соединения. 

- `ambari_server__db_name` - Название БД для Ambari Server.

- `ambari_server__db_user` - Имя роли PostgreSQL для работы с БД.

- `ambari_server__db_user_pass` - Пароль `ambari_server__db_user`.

- `ambari_server__start_service` - признак запуска сервиса ambari-server после установки. По умолчанию 'true'.

### LDAP
- `ambari_server__ldap_type` - тип ldap сервера. Варианты - AD/IPA/Generic. По умолчанию 'AD'.
- `ambari_server__ldap_url` - ссылка на ldap/ad сервер (с портом)
- `ambari_server__ldap_secondary_url` - ссылка на дополнительный ldap/ad сервер (с портом)
- `ambari_server__ldap_ssl` - признак использования ssl для соединения по ldap. По умолчанию 'false'
- `ambari_server__ldap_bind_anonym` - aнонимная авторизация в ldap. По умолчанию 'false'
- `ambari_server__ldap_manager_dn` - DN пользователя для авторизации в ldap/ad
- `ambari_server__ldap_manager_password` - пароль пользователя `ambari_server__ldap_manager_dn`
- `ambari_server__ldap_base_dn` - base DN для поиска записей в ldap. По умолчанию 'DC=msk,DC=mts,DC=ru'
- `ambari_server__ldap_dn_attr` -  атрибут для определения DN. По умолчанию 'distinguishedName'
- `ambari_server__ldap_user_class` -  имя класса объекта в ldap для пользователей. По умолчанию 'user'
- `ambari_server__ldap_user_attr` - атрибут для определения имени пользователя Ambari. По умолчанию 'sAMAccountName'
- `ambari_server__ldap_group_class` - имя класса объекта в ldap для групп. По умолчанию 'group'
- `ambari_server__ldap_group_attr` - атрибут для определения наименования группы в Ambari. По умолчанию 'sAMAccountName'
- `ambari_server__ldap_member_attr` - атрибут для определения списка членов группы. По умолчанию 'member'.
- `ambari_server__ldap_referral` -  По умолчанию 'follow'
- `ambari_server__ldap_force_lowercase_usernames` - принудительная конвертация имен пользователей в нижний регистр. По умолчанию 'true'
- `ambari_server__ldap_username_collisions_behavior` - По умолчанию 'convert'
- `ambari_server__ldap_pagination_enabled` -  По умолчанию 'false'
- `ambari_server__ldap_sync_disable_endpoint_identification` - По умолчанию 'false'
- `ambari_server__groups_ldap` - Список групп LDAP для синхронизации с Ambari.
