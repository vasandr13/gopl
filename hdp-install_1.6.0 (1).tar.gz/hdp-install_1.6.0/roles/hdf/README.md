# hdf

Hortonworks dataflow (HDF) setup ansible role.

## Разработка

Maintainer: @dslampsy

Разработка должна вестись в отдельных ветках, с MR в мастер который вешается на maintainer. После merge ветки будут удаляться. Для версионирования используется [semver](https://semver.org).
