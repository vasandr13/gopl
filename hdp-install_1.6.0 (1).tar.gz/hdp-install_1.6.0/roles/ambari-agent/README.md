# ambari-agent

Роль ansible для операций с Ambari Agent.

## Разработка 

Maintainer: @dslampsy

Разработка должна вестись в отдельных ветках, с MR в мастер который вешается на maintainer. После merge ветки будут удаляться. 

Для версионирования используется semver - https://semver.org/. 


## Использование

```yaml
- name: "Prechecks hosts for Ambari Agents install"
  hosts: ...
  vars:
    ambari_agent__server: "ambari.fake.ru"
  roles:
    - { role: ambari-agent, ambari_agent__action: prechecks }

- name: "Prepare hosts for Ambari Agents install"
  hosts: ...
  vars:
    ambari_agent__server: "ambari.fake.ru"
  roles:
    - { role: ambari-agent, ambari_agent__action: prepare }

- name: "Install Ambari Agent"
  hosts: ...
  vars:
    ambari_agent__version: "2.7.3.0"
    ambari_agent__server: "ambari-server.foo.bar"
  roles:
    - { role: ambari-agent, ambari_agent__action: setup }

- name: "Delete Ambari Agent"
  hosts: ...
  roles:
    - { role: ambari-agent, ambari_agent__action: delete }
```


## Переменные

- `ambari_agent__action` - тип операции выполняемой в роли. Доступные операции:
  - `prechecks` - проверки конфигурации хоста перед установкой Ambari Agent.
  - `prepare` - подготовка хоста для установки Ambari Agent. Включает в себя шаг `repo`.
  - `repo` - настройка репозиториев для Ambari Agent.
  - `setup` - установка и настрйока Ambari Agent. НЕ включает в себя шаги `prechecks`, `prepare`, их необходимо запустить до установки.
  - `configure` - конфигурирование настроек для Ambari Agent.
  - `delete` - удаление Ambari Agent.

- `ambari_agent__version` - версия Ambari Agent для установки. По умолчанию: '2.6.2.0'

- `ambari_agent__repofile` - ссылка на файл репозитория для скачивания на хост. По умолчанию: 'http://rep.msk.mts.ru/artifactory/files/repofiles/Ambari-{{ ambari_agent__version }}.repo'

- `ambari_agent__server` - имя хоста Ambari Server с которым будет работать агент.

- `ambari_agent__start_service` - признак запуска сервиса ambari-agent после установки. По умолчанию 'true'.