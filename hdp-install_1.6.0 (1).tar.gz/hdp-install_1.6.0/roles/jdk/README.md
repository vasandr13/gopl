# jdk

Роль ansible для установки JDK.


## Использование

```yaml
- name: "Install JDK"
  hosts: ...
  vars:
    ...
  roles:
    - role: jdk
      jdk__action: setup

```


## Переменные

- `jdk__action` - тип операции выполняемой в роли. Доступные операции:
  - `setup` - установка JDK.
  - `delete` - удаление **всех** пакетов JDK (через yum).

- `jdk__version` - Версия JDK. По умолчанию - '8u171'.

- `jdk__home` - Итоговый путь к JDK. По умолчанию - '/usr/java/jdk1.8.0_171'.

- `jdk__src` - Ссылка на пакет в репозитории. По умолчанию - '"http://rep.msk.mts.ru/artifactory/common-rpm/jdk-{{ jdk__version }}-linux-x64.rpm"'


## Авторы
  - Лампси Дмитрий Сергеевич - <dslampsy@mts.ru>