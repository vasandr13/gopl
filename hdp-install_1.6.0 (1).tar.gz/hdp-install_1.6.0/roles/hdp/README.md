# hdp

Роль для установки и конфигурирования HDP кластера.

Оглавление:
1. [Разработка](https://git.bd.msk.mts.ru/ansible-roles/hdp#%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B0)
2. [Использование](https://git.bd.msk.mts.ru/ansible-roles/hdp#%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5)
3. [Переменные](https://git.bd.msk.mts.ru/ansible-roles/hdp#%D0%BF%D0%B5%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%BD%D1%8B%D0%B5)
4. [Prechecks](https://git.bd.msk.mts.ru/ansible-roles/hdp#prechecks)
5. [Datasource](https://git.bd.msk.mts.ru/ansible-roles/hdp#datasource)

## Разработка 

Maintainer: @dslampsy

> Разработка должна вестись в отдельных ветках, с последующим MR в мастер который назначается на maintainerа. После MR ветки будут удаляться. Для версионирования используется [semver](https://semver.org/).


## Использование

```yaml
- name: Precheck hosts for HDP install
  hosts: ...
  vars:
    ...
  roles:
    - { role: hdp, hdp__action: prechecks }

- name: Add hosts to /etc/hosts
  hosts: ...
  roles:
    - { role: hdp, hdp__action: 'prepare/etc_hosts' }


- name: Add oraclelinux optional repo
  hosts: ...
  roles:
    - { role: hdp, hdp__action: 'prepare/repo' }


- name: Install dependencies
  hosts: ...
  roles:
    - { role: hdp, hdp__action: 'prepare/dependencies' }


- name: Add cert to Java keystore
  hosts: ...
  vars:
    hdp__java_cert_keystore_path: "/usr/java/jdk1.8.0_201-amd64/jre/lib/security/cacerts"
    hdp__java_cert_hosts:
      - { url: "0400MSKRWDC04.msk.mts.ru", port: "636" }
  roles:
    - { role: hdp, hdp__action: 'prepare/java_cert' }


- name: Clean host from zookeeper component
  hosts: ...
  roles:
    - { role: hdp, hdp__action: 'cleaner/zookeeper' }


- name: Stop HDP services
  hosts: ...
  roles:
    - { role: hdp, hdp__action: 'stop/namenode' }
    - { role: hdp, hdp__action: 'stop/zookeeper' }
    ...

- name: Clean host from all HDP component
  hosts: ...
  roles:
    - { role: hdp, hdp__action: 'cleaner/all' }
```


## Переменные

- `hdp__action` - тип операции выполняемой в роли. Доступные операции:
  - `prechecks` - запуск проверок серверов перед установкой HDP
  - `prepare/etc_hosts` - добавление хостов из указанной inventory группы в /etc/hosts
  - `prepare/java_cert` - добавление сертификата в java keystore
  - `prepare/spark_llap` - добавление spark-llap-assembly
  - `stop/...` - остановка сервисов HDP на хостах. Доступный список компонент можно посмотреть в каталоге `tasks/stop/`
  - `cleaner/...` - очистка хоста от компонент HDP. Доступный список компонент можно посмотреть в каталоге `tasks/cleaner/`. Так же есть действие `all` для удаления всех возможных компонент HDP с хоста

- `hdp__rootvol_size` - размер root раздела на сервере. Опционально, используется при `hdp__action: prechecks`.

- `hdp__grids_num` - кол-во grid разделов на сервере. Опционально, используется при `hdp__action: prechecks`.

- `hdp__mount_points` - список смонтированных каталогов в ОС, для проверки на наличие. Опционально, используется при `hdp__action: prechecks`.

- `hdp__swap_size` - размер Swap на сервере. Опционально, используется при `hdp__action: prechecks`.

- `hdp__java_cert_hosts` - список серверов, откуда нужно получить сертификат. По умолчанию '[]'.

  Пример:
  ```yaml
  hdp__java_cert_hosts:
    - { url: "foo.bar1", port: "636" }
    - { url: "foo.bar2", port: "636" }
  ```
  
- `hdp__java_cert_keystore_path` - путь к java keystore для добавления в него сертификата.

- `hdp__java_cert_keystore_pass` - пароль для java keystore. По умолчанию 'changeit'.

- `hdp__min_free_kbytes_check` - признак запуска проверки параметра `vm.min_free_kbytes` в в `/etc/sysctl.conf`. По умолчанию 'true'.

- `hdp__repo_check` - признак запуска проверки доступности репозиториев на хостах. По умолчанию 'false'

- `hdp__repo` - ссылка на репозиторий HDP. По умолчанию - 'http://rep.msk.mts.ru/artifactory/hortonworks/HDP/centos7/3.x/updates/3.1.0.0/'

- `hdp__repo_utils` - ссылка на репозиторий HDP-Utils. По умолчанию - 'http://rep.msk.mts.ru/artifactory/hortonworks/HDP-UTILS-1.1.0.22/repos/centos7/'

- `hdp__repo_gpl` - ссылка на репозиторий HDP-Gpl. По умолчанию - 'http://rep.msk.mts.ru/artifactory/hortonworks/HDP-GPL/centos7/3.x/updates/3.1.0.0/'

## Prechecks

Выполняемые в шаге `prechecks` операции:

1. Проверка размера root раздела. Запускается только при указании переменной `hdp__rootvol_size`.
2. Проверка кол-во подключённых grid. Запускается только при указании переменной `hdp__grids_num`.
3. Проверка наличия точек монтирования в указанных каталогах. Запускается только при указании переменной `hdp__mount_points`.
4. Проверка swap size. Запускается только при указании переменной `hdp__swap_size`.
5. Проверка что на хостах отключена функция Transparent Hugepage. 
6. Проверка заданного в `/etc/sysctl.conf` параметра `vm.min_free_kbytes`. Запускается только при `hdp__min_free_kbytes_check: true`
7. Проверка заданного в `/etc/sysctl.conf` параметра `kernel.pid_max`. Сравнивается с переменной `hdp__pid_max_value` (default: `114688`), должно быть больше или равно. Запускается только при `hdp__pid_max_check: true`
8. Проверка указанного в inventory имени хоста с заданным на сервере. Провекра производится 2-мя способами - проверкой через команду 'hostname -f' и через 'hostnamectl status --static'.
9. Проверка доступности репозиториев HDP с хоста. Запускается только при `hdp__repo_check: true`

Примеры использования:

```yaml
- name: Precheck hosts for HDP install
  hosts: ...
  vars:
    hdp__rootvol_size:
    hdp__grids_num:
    hdp__mount_points: []
    hdp__swap_size:
  roles:
    - { role: hdp, hdp__action: prechecks }


- name: Precheck with repo check
  hosts: ...
  vars:
    hdp__repo_check: true
  roles:
    - { role: hdp, hdp__action: prechecks }


- name: Precheck without min_free_kbytes check
  hosts: ...
  vars:
    hdp__min_free_kbytes_check: false
  roles:
    - { role: hdp, hdp__action: prechecks }
```

## Datasource

Настройка Datasource для компонент HDP. 

Достумные datasource: `ranger`, `hive`, `oozie`.

При выполнении действий, так же устаналивается библиоткеа python - `psycopg2`. Действия необходимо запускать на хосте с Postgres.


```yaml
- name: Create ranger datasource
  hosts: ...
  vars:
    hdp__ranger_db: ranger
    hdp__ranger_db_user: ranger
    hdp__ranger_db_user_pass: ranger
    hdp__datasource_become_user: postgres
  roles:
    - { role: hdp, hdp__action: prechecks }
```

Переменные:

  - `hdp__datasource_become_user` - пользователь из-под которого будет производиться операции модуля ansible - postgresql_user. По умолчанию - 'postgres'.

  - `hdp__ranger_db` - название datasource для ranger
  - `hdp__ranger_db_user` - имя пользователя datasource для ranger
  - `hdp__ranger_db_user_pass` - пароль пользователя hdp__ranger_db_user

  - `hdp__hive_db` - название datasource для hive
  - `hdp__hive_db_user` - имя пользователя datasource для hive
  - `hdp__hive_db_user_pass` - пароль пользователя hdp__hive_db_user

  - `hdp__oozie_db` - название datasource для oozie
  - `hdp__oozie_db_user` - имя пользователя datasource для oozie
  - `hdp__oozie_db_user_pass` - пароль пользователя hdp__oozie_db_user
  